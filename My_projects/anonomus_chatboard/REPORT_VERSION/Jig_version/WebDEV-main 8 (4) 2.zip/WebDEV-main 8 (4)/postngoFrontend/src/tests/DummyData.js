exports.DummyData = {
    posts: [
    {
        postId: 114514,
        content: "Prof. Jal is one of two professors among all Towson lecturers who did not make me sleepy during the lecture. His lecture progresses in a very steady and energetic pace. He is very knowledgeable about trending technologies. I have been doing front-end for years but I still learn a bunch of new details from his class. Strongly recommended",
        author: "Haotong",
        likes: 5
    },
    {
        postId: 318759,
        content: "According to all known laws of aviation, there is no way that a bee should be able to fly. Its wings are too small to get its fat little body off the ground. The bee, of course, flies anyways. Because bees don't care what humans think is impossible.",
        author: "Saint",
        likes: 99
    },
    {
        postId: 127591,
        content: "Jal is one of the best AIT professors I've had so far. He explains the material well, the class moves at a good pace, and he is always available for questions. He also knows a lot besides the course material and is willing to connect you with alumni. Even if you don't like web development, you'll learn a lot from him.",
        author: "Josue",
        likes: 6
    }
]};